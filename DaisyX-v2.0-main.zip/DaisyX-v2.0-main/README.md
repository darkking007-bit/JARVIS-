<p align='center'>
  <a href="https://www.python.org/" alt="made-with-python"> <img src="https://img.shields.io/badge/Made%20with-Python-1f425f.svg?style=flat-square&logo=python&color=blue" /> </a>
  <a href="https://github.com/TeamDaisyX/DaisyX-v2/graphs/commit-activity" alt="Maintenance"> <img src="https://img.shields.io/badge/Maintained%3F-yes-green.svg?style=flat-square" /> </a>
</p>
<h1 align="center"><b> DaisyX 2.0  </b></h1>
<h4 align="center">A Powerful, Smart And Simple Group Manager <br> ... Written with AioGram , Pyrogram and Telethon...</h4>
<p align="center">
    <a href="https://github.com/TeamDaisyX/daisyx-v2.0/commits/main"><img src="https://img.shields.io/github/last-commit/TeamDaisyX/daisyx-v2.0/main?label=Last%20Commit&style=flat-square&logo=github&color=F10070" alt="Commit" /></a>
    <a href="https://github.com/TeamDaisyX/daisyx-v2.0/stargazers"><img src="https://img.shields.io/github/stars/TeamDaisyX/daisyx-v2.0?label=Stars&style=flat-square&logo=github&color=F10070" alt="Stars" /></a>
    <a href="https://github.com/TeamDaisyX/daisyx-v2.0/network/members"><img src="https://img.shields.io/github/forks/TeamDaisyX/daisyx-v2.0?label=Fork&style=flat-square&logo=github&color=F10070" alt="Fork" /></a>
    <a href="https://github.com/TeamDaisyX/daisyx-v2.0/watchers"><img src="https://img.shields.io/github/watchers/TeamDaisyX/daisyx-v2.0?label=Watch&style=flat-square&logo=github&color=F10070" alt="Watch" /></a>
    <a href="https://github.com/TeamDaisyX/daisyx-v2.0/graphs/contributors"><img src="https://img.shields.io/github/contributors-anon/TeamDaisyX/daisyx-v2.0?label=Contributors&style=flat-square&logo=github&color=F10070" alt="Contributors" /></a>  
    <a href="https://www.codacy.com/gh/TeamDaisyX/daisyx-v2.0/dashboard?utm_source=github.com&amp;utm_medium=referral&amp;utm_content=TeamDaisyX/daisyx-v2.0&amp;utmcampaign=Badge_Grade"><img src="https://img.shields.io/codacy/grade/a3a19d2b551641039ec7edc3aa7b8c5d?style=flat-square&logo=codacy&color=F10070" alt="codacy badge"/></a> 
</p>

### The first AioGram based modified groupmanagement bot fully optimized for heroku deploys
## https://daisyproject.studio
## Avaiilable on Telegram as [@DaisyXBot](https://t.me/daisyxbot)

[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/TeamDaisyX/DaisyX-v2.0.git)

## Credits

 - [Hitsuki](https://github.com/HitsukiNetwork/Hitsukix)
 - [Utah](https://github.com/minatouzuki/utah)
 - [FridayUserbot](https://github.com/DevsExpo/FridayUserbot)
 - [MissJuliaRobot](https://github.com/MissJuliaRobot/MissJuliaRobot)
 - [DaisyX](https://github.com/teamdaisyx/daisy-x)
 - [Masha](https://github.com/Mr-Dark-Prince/MashaRoBot/)


The bot is based on the original work done by [SophieBot](https://gitlab.com/SophieBot/sophie)
This repo was just revamped to suit an Anime-centric & comedy loving community. All original credits go to SophieBot and their dedication, Without his efforts, this fork would not have been possible!

All other credits mentioned on top of scripts

Anything missing kindly let us know at [Daisy Support](https://t.me/DaisySupport_Official) or simply submit a pull request on the readme.

## Daisy X the telegram Bot Project
DaisyX-v2.0 (Base AioGram)


## Special Credits
- [@Kaviya-Admin](https://github.com/kaviya-admin) - A Developer of Project
- [@Anjana_Ma](https://github.com/Anjana_Ma) - A Developer of Project
- [Dark Prince](https://github.com/Mr-Dark-Prince) - A Co-Developer of Project
- [Official_Bawwa](https://github.com/OfficialBawwa) - A Developer of Project
- [Inuka Asith](https://github.com/inukaasith) - A Developer of the project
- [annihilatorrrr](https://github.com/annihilatorrrr) - A Co-Developer of Project
- [@sithum batrow](https://github.com/sbatrow) - A Developer of Project
- @tamilvip007 - Helper
- @charindith - Helper
- @mubashirrehman - Helper
- For you..

And as always thanks to AioGram devs, Dan for pyrogram, lonami for telethon and Durov for telegram
Special thanks to you for using bot
