__mod_name__ = "Music Player"
__help__ = """
<b> VC PLAYER </b>
VC player plays plays music in your group's voice chat

<b> Setting up </b>
1) Add @DaisyXAssistant to your group
2) Make bot admin
3) Start a voice chat

<b> Commands </b>
- /play [link/ reply: mp3 file or yt link] : Play/Add to queue of given song
- /pause : Pause music play (Admin only)
- /skip : Skips current song (Admin only)
- /end : End the music play (Admin only)

<b> PLEASE NOTE THIS IS HEAVILY UNSTABLE AND CAN BE STOPPED ANYTIME </b>
"""
